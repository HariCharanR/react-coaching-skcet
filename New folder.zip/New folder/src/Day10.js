import React from 'react'

function Day10() {
  return (
    <div>
      
    </div>
  )
}

export default Day10
